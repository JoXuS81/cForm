/* Table of Contents

1. Pull page on the top 

*/


/* Pull page on the top */
$(document).ready(function() {
    $(this).scrollTop(0);
});